apt-get update -q -y
apt-get install -y python3-pip
pip install --upgrade pip
pip install bandit
pip install black
pip install flake8
pip install radon
pip install ruff
pip install pylint
pip install pytest
pip install pytest-cov
pip install isort
pip install pydantic
pip install pydantic_core
pip install jsonschema Flask
pip install flask-restplus
pip install requests
apt install bc
